from articles.api.views import FinalCSVViewSet, PortfolioViewSet, UserViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'matrix', FinalCSVViewSet, basename='matrix')
router.register(r'portfolio', PortfolioViewSet, basename='portfolios')
router.register(r'user', UserViewSet, basename='users')
urlpatterns = router.urls