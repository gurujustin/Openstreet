// import { combineReducers } from "redux"
// import { reducer } from "./loginReducer"
// import { register } from "./registerReducers"

// const authReducers = combineReducers({
//   reducer,
//   register
// })

// export default authReducers
